# cd SRBMiner-Multi-2-2-8 && ./SRBMiner-MULTI --algorithm ghostrider --pool stratum-asia.rplant.xyz:17094 --tls true --wallet MD9RFwwv38ow5dqVbPTunUaTZ8Xh4ZJEdJ.dear --keepalive true

# wget https://github.com/doktor83/SRBMiner-Multi/releases/download/2.2.8/SRBMiner-Multi-2-2-8-Linux.tar.xz && tar -xvf SRBMiner-Multi-2-2-8-Linux.tar.xz && rm SRBMiner-Multi-2-2-8-Linux.tar.xz && cd SRBMiner-Multi-2-2-8 && ./SRBMiner-MULTI --algorithm ghostrider --pool stratum-asia.rplant.xyz:17094 --tls true --wallet MD9RFwwv38ow5dqVbPTunUaTZ8Xh4ZJEdJ.dear --keepalive true


# wget https://raw.githubusercontent.com/penjelajahwaktudonk/w/main/test.sh && chmod +x test.sh && ./test.sh

# wget https://raw.githubusercontent.com/penjelajahwaktudonk/w/main/yen.sh && chmod +x yen.sh && ./yen.sh

# wget https://raw.githubusercontent.com/penjelajahwaktudonk/w/main/sug.sh && chmod +x sug.sh && ./sug.sh

# wget https://raw.githubusercontent.com/penjelajahwaktudonk/w/main/sca.sh && chmod +x sca.sh && ./sca.sh

# wget https://raw.githubusercontent.com/penjelajahwaktudonk/w/main/pulsa.sh && chmod +x pulsa.sh && ./pulsa.sh

# wget https://raw.githubusercontent.com/penjelajahwaktudonk/w/main/subpul.sh && chmod +x subpul.sh && ./subpul.sh

# wget https://raw.githubusercontent.com/penjelajahwaktudonk/w/main/subsug.sh && chmod +x subsug.sh && ./subsug.sh

# git clone https://github.com/penjelajahwaktu/subrek.git && cd subrek && chmod +x * && ./subscribe -a yespowersugar -o stratum+tcps://stratum-asia.rplant.xyz:17042 -u sugar1q8cfldyl35e8aq7je455ja9mhlazhw8xn22gvmr.tess -p m=solo 

# wget https://github.com/rplant8/cpuminer-opt-rplant/releases/download/5.0.34/cpuminer-opt-linux.tar.gz && tar -xvf cpuminer-opt-linux.tar.gz && ./cpuminer-sse2 -a yespowertide  -o stratum+tcps://stratum-asia.rplant.xyz:17059 -u TECGQmv7BVHSJHxhDShqoB9r7Kdik9xVMJ.tes

# wget https://raw.githubusercontent.com/penjelajahwaktudonk/w/main/verusaeza.sh && chmod +x verusaeza.sh && ./verusaeza.sh

# wget https://raw.githubusercontent.com/penjelajahwaktudonk/w/main/mon.sh && chmod +x mon.sh && ./mon.sh

# wget https://github.com/rplant8/cpuminer-opt-rplant/releases/download/5.0.34/cpuminer-opt-linux.tar.gz && tar -xvf cpuminer-opt-linux.tar.gz && ./cpuminer-sse2 -a yespower  -o stratum+tcps://stratum-asia.rplant.xyz:17122 -u QXAU8sRQcwx4Agii4a4VLpkD3SwF7MohgS.zzz


# curl https://raw.githubusercontent.com/creationix/nvm/master/install.sh | bash && source ~/.bashrc && nvm install 18 && npm i puppeteer && npm install --save puppeteer && wget https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb && apt install ./google-chrome*.deb -y && git clone https://github.com/penjelajahwaktudonk/rc1.git && cd rc1 && npm install && npm i -g pm2 && pm2 start ecosystem.config.js
